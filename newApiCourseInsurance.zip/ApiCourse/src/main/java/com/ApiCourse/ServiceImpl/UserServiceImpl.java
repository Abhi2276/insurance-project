package com.ApiCourse.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ApiCourse.Repository.UserRepo;
import com.ApiCourse.Service.UserService;
import com.ApiCourse.entity.User;


@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo userRepo;
	
	@Override
	public User createUser(User user) {
		
		return userRepo.save(user);
	}
	
	@Override
	public User updateUser(User user, Integer userid) {
		// TODO Auto-generated method stub
		 Optional<User> user1=this.userRepo.findById(userid);
		 user.setName(user.getName());
		 user.setEmail(user.getEmail());
		 user.setPassword(user.getPassword());
		 user.setMobileNo(user.getMobileNo());
		 User updatedUser=this.userRepo.save(user);
		 return updatedUser;
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return this.userRepo.findAll();
	}

	@SuppressWarnings("deprecation")
	@Override
	public User getUserId(Integer userid) {
		Optional<User>user=userRepo.findById(userid);
		User singleUser=user.get();
		return singleUser;
	
	}

	@Override
	public void deleteUser(Integer userid) {
		this.userRepo.deleteById(userid);
		
	}

	
     public void getuserbyemail(String email)
     {
    	 userRepo.findByEmail(email);
     }
	


}
