package com.ApiCourse.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ApiCourse.Repository.VehicleRepo;
import com.ApiCourse.Service.VehicleService;
import com.ApiCourse.entity.Vehicle;

@Service
public class VehicleServiceImpl  implements VehicleService{

	@Autowired
	private VehicleRepo vehicleRepo;
	
	@Override
	public Vehicle createVehicle(Vehicle vehicle) {
	
		return this.vehicleRepo.save(vehicle);
	}

	@Override
	public List<Vehicle> getVehicle() {
		
		return vehicleRepo.findAll();
	}

}
