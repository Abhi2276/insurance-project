package com.ApiCourse.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ApiCourse.Repository.CourseDao;
import com.ApiCourse.Service.CourseService;
import com.ApiCourse.entity.Course;
@Service
public class CourseServiceImpl implements CourseService{
	@Autowired
	private CourseDao courseDao;

	@Override
	public List<Course> getCourse() {
		
		
		return courseDao.findAll();
	}

	@Override
	public Course getCourse(long courseId) {
		
		return courseDao.getOne(courseId);       
	}

	@Override
	public Course addCourse(Course course) {
		
		return courseDao.save(course);
	}

	@Override
	public Course updateCourse(Course course) {
		
		return courseDao.save(course);
	}
	

}
