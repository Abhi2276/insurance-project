package com.ApiCourse.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.ApiCourse.Repository.InsuranceRepo;
import com.ApiCourse.Repository.UserRepo;
import com.ApiCourse.Service.InsuranceService;
import com.ApiCourse.entity.InsuranceDetails;
import com.ApiCourse.entity.User;

@Service
public class InsuranceServiceImpl  implements InsuranceService{
	
	@Autowired
	private InsuranceRepo insuranceRepo;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private User user;

	@Override
	public InsuranceDetails createInsuranceDetails(InsuranceDetails insuranceDetails,Integer userId) {
          
		User user=this.userRepo.findById(userId).orElse(null);
		
		insuranceDetails.setUser(user);
		
		InsuranceDetails newDetails=this.insuranceRepo.save(insuranceDetails);
		return newDetails;
	}

	@Override
	public InsuranceDetails updateInsuranceDetails(InsuranceDetails insuranceDetails, Integer insuranceDetailsId) {
		Optional<InsuranceDetails> optional=this.insuranceRepo.findById(insuranceDetailsId);
		insuranceDetails.setInsuranceNumber(insuranceDetails.getInsuranceNumber());
		insuranceDetails.setProvider(insuranceDetails.getProvider());
		insuranceDetails.setValidDate(insuranceDetails.getValidDate());
		
		InsuranceDetails updatedDetails=this.insuranceRepo.save(insuranceDetails);
		return updatedDetails;
		
	}

	@Override
	public List<InsuranceDetails> getAllInsuranceDetails() {
		
		List<InsuranceDetails> allDetails=this.insuranceRepo.findAll();
		
		return allDetails;
	}

	
	@Override
	public InsuranceDetails getInsuranceDetailsById(Integer insuranceDetailsId) {
		Optional<InsuranceDetails> optional=insuranceRepo.findById(insuranceDetailsId);
		 InsuranceDetails singleDetails=optional.get();
		return singleDetails;
	}
	
	

	@Override
	public void  deleteInsuranceDetails(Integer insuranceDetailsId) {
	
		
		insuranceRepo.deleteById(insuranceDetailsId);
		
	}

	@Override
	public List<InsuranceDetails> getInsuranceDetailsByUser(Integer userId) {
	Optional<User> user=this.userRepo.findById(userId);
	List<InsuranceDetails> insdet=this.insuranceRepo.findByUser(user);
	
		return insdet;
	}

}
