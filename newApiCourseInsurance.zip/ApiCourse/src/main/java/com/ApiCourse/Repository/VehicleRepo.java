package com.ApiCourse.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ApiCourse.entity.Vehicle;

public interface VehicleRepo extends JpaRepository<Vehicle, Integer> {
	
	

}
