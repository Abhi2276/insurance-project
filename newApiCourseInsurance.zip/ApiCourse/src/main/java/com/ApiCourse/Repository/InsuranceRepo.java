package com.ApiCourse.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ApiCourse.entity.InsuranceDetails;
import com.ApiCourse.entity.User;



public interface InsuranceRepo extends JpaRepository<InsuranceDetails, Integer>{
	
	List<InsuranceDetails> findByUser(Optional<User> user);

}
