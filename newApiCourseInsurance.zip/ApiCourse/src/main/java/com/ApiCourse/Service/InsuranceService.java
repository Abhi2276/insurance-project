package com.ApiCourse.Service;

import java.util.List;

import com.ApiCourse.entity.InsuranceDetails;
import com.ApiCourse.entity.User;

public interface InsuranceService {
	
	InsuranceDetails createInsuranceDetails(InsuranceDetails insuranceDetails,Integer userId);
	
	InsuranceDetails updateInsuranceDetails(InsuranceDetails insuranceDetails,Integer insuranceDetailsId);
	
	List<InsuranceDetails> getAllInsuranceDetails();
	
	InsuranceDetails getInsuranceDetailsById(Integer insuranceDetailsId);
	
	void deleteInsuranceDetails(Integer insuranceDetailsId);
	
	List<InsuranceDetails> getInsuranceDetailsByUser(Integer userId);
	

}
