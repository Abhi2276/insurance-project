package com.ApiCourse.Service;

import java.util.List;

import com.ApiCourse.entity.User;

public interface UserService {
	
	public User createUser(User user);
	
    User updateUser(User user,Integer userid);
	
	List<User> getAllUser();
	
	User getUserId(Integer userid);
	
	void deleteUser(Integer userId);
	
	
	
	

}
