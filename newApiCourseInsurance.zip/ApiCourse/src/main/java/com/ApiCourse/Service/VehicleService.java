package com.ApiCourse.Service;

import java.util.List;

import com.ApiCourse.entity.Vehicle;

public interface VehicleService {
	
	Vehicle createVehicle(Vehicle vehicle);
	
    public List<Vehicle> getVehicle();

}
