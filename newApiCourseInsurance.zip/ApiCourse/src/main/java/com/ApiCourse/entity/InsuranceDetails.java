package com.ApiCourse.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="insuranceDetails")
public class InsuranceDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Insuranceid;
	
	private String provider;
	
	private String insuranceNumber;
	
	private String validDate;
	
	@OneToOne(fetch = FetchType.LAZY)
	private User user;

	public InsuranceDetails(int insuranceid, String provider, String insuranceNumber, String validDate, User user) {
		super();
		Insuranceid = insuranceid;
		this.provider = provider;
		this.insuranceNumber = insuranceNumber;
		this.validDate = validDate;
		this.user = user;
	}

	public InsuranceDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getInsuranceid() {
		return Insuranceid;
	}

	public void setInsuranceid(int insuranceid) {
		Insuranceid = insuranceid;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getInsuranceNumber() {
		return insuranceNumber;
	}

	public void setInsuranceNumber(String insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}

	public String getValidDate() {
		return validDate;
	}

	public void setValidDate(String validDate) {
		this.validDate = validDate;
	}
	
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "InsuranceDetails [Insuranceid=" + Insuranceid + ", provider=" + provider + ", insuranceNumber="
				+ insuranceNumber + ", validDate=" + validDate + ", user=" + user + "]";
	}
	
	
	
	
	
	
	

	
	

}
