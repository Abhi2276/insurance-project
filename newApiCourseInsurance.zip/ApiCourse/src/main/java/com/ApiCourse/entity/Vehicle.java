package com.ApiCourse.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vehicle")
public class Vehicle {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String category;
	private String type;
	private String manufacturer;
 
    private String color;
    private String registrationDate;
	public Vehicle(int id, String category, String type, String manufacturer, String color, String registrationDate) {
		super();
		this.id = id;
		this.category = category;
		this.type = type;
		this.manufacturer = manufacturer;
		this.color = color;
		this.registrationDate = registrationDate;
	}
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", category=" + category + ", type=" + type + ", manufacturer=" + manufacturer
				+ ", color=" + color + ", registrationDate=" + registrationDate + "]";
	}
    
    
}
