package com.ApiCourse.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ApiCourse.Service.VehicleService;
import com.ApiCourse.entity.Vehicle;
import java.util.List;


@RestController
@RequestMapping("/vehicle")
public class VehicleController {
	
	@Autowired
	private VehicleService vehicleService;

	@PostMapping("/add")
	public Vehicle addVehicle(@RequestBody Vehicle vehicle)
	{
		return this.vehicleService.createVehicle(vehicle);
	}
	
	@GetMapping("/get")
	public List<Vehicle> getAllVehicle()
	{
		return this.vehicleService.getVehicle();
	}
}
