package com.ApiCourse.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ApiCourse.Service.InsuranceService;
import com.ApiCourse.entity.InsuranceDetails;

@RestController
@RequestMapping("/insuranceDetails")
public class InsuranceController {
	
	@Autowired
	private InsuranceService insuranceService;
	

	@PostMapping("/create/user/{userId}")
	public ResponseEntity<InsuranceDetails> createInsurance(@RequestBody InsuranceDetails insuranceDetails,@PathVariable Integer userId)
	{
		InsuranceDetails createDetails=this.insuranceService.createInsuranceDetails(insuranceDetails,userId);
		
		
		return new ResponseEntity<InsuranceDetails>(createDetails,HttpStatus.CREATED);
	}
	
	@PutMapping("/{insuranceDetailsId}")
	public ResponseEntity<InsuranceDetails> updateInsurance(@RequestBody  InsuranceDetails insuranceDetails,@PathVariable Integer insuranceDetailsId)
	{
	 InsuranceDetails updatedDetails=this.insuranceService.updateInsuranceDetails(insuranceDetails,insuranceDetailsId);
	 
	 return new ResponseEntity<>(updatedDetails,HttpStatus.OK);
	}
	
	
	@GetMapping("/allDetails")
	public List<InsuranceDetails> getAllInsuranceDetails() 
	{
		
		return this.insuranceService.getAllInsuranceDetails();
	
	}
	
	@GetMapping("/insuranceUser/{insuranceDetailsId}")
	public ResponseEntity<InsuranceDetails> getInsuranceDetailsById(@PathVariable Integer insuranceDetailsId)
	{
		return ResponseEntity.ok(this.insuranceService.getInsuranceDetailsById(insuranceDetailsId));
	}
	
	
	@DeleteMapping("/{insuranceDetailsId}")
	public ResponseEntity<?> deleteInsuranceDetails(@PathVariable Integer insuranceDetailsId)
	{
		this.insuranceService.deleteInsuranceDetails(insuranceDetailsId);
		return ResponseEntity.ok("deleted");
	}
	
	@GetMapping("/user/{userId}")
	public ResponseEntity<List<InsuranceDetails>> getInsuranceDetailsByUser(@PathVariable Integer userId)
	{
		return ResponseEntity.ok(this.insuranceService.getInsuranceDetailsByUser(userId));
	}
	
	
	
}
